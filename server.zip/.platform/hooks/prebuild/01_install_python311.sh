#!/bin/bash
set -e

# yt-dlp (used by youtube-dl-exec) requires Python 3.10+.
# Amazon Linux ships with Python 3.9 as /usr/bin/python3 - leave that alone
# (dnf/yum depend on it) and instead put a newer python earlier in PATH.

if command -v dnf >/dev/null 2>&1; then
  sudo dnf install -y python3.11
elif command -v yum >/dev/null 2>&1; then
  sudo yum install -y python3.11
else
  echo "Neither dnf nor yum found - cannot install python3.11" >&2
  exit 1
fi

# /usr/local/bin comes before /usr/bin in the default systemd PATH,
# so this symlink is what the node process (and yt-dlp's shebang) will pick up.
sudo ln -sf "$(command -v python3.11)" /usr/local/bin/python3

python3 --version
